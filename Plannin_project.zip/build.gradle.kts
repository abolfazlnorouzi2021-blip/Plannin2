buildscript {
    dependencies {
        // AGP 9 ships with built-in Kotlin; pin a newer KGP for the matching Compose compiler plugin.
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.21")
    }
}

plugins {
    id("com.android.application") version "9.5.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.21" apply false
    id("com.android.legacy-kapt") version "9.5.0" apply false
}
