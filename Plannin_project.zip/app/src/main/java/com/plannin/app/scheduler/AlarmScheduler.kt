package com.plannin.app.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.plannin.app.data.local.HabitEntity
import com.plannin.app.data.local.TimeBlockEntity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object AlarmScheduler {
    const val EXTRA_EVENT_TYPE = "event_type"
    const val EXTRA_BLOCK_ID = "block_id"
    const val EXTRA_PROJECT_ID = "project_id"
    const val EXTRA_TITLE = "title"
    const val EXTRA_CHANNEL_ID = "channel_id"
    const val EVENT_START = "BLOCK_START"
    const val EVENT_CHECK_IN = "BLOCK_CHECK_IN"
    const val EVENT_HABIT = "HABIT"

    fun scheduleUpcoming(context: Context, blocks: List<TimeBlockEntity>, habits: List<HabitEntity>) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val today = LocalDate.now()
        val now = LocalDateTime.now()

        blocks.filter { it.blockType == "PROJECT" && it.isEnabled && !it.isFlexible }.forEach { block ->
            for (offset in 0..7) {
                val date = today.plusDays(offset.toLong())
                if (date.dayOfWeek.value != block.dayOfWeekIso) continue
                val start = LocalDateTime.of(date, LocalTime.of(block.startMinute / 60, block.startMinute % 60))
                val end = LocalDateTime.of(date, LocalTime.of(block.endMinute / 60, block.endMinute % 60))
                val projectId = block.projectId ?: continue
                if (block.startNotification && start.isAfter(now)) {
                    schedule(alarmManager, context, start.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), block, EVENT_START, date.toEpochDay())
                }
                if (block.checkInNotification && end.isAfter(now)) {
                    schedule(alarmManager, context, end.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), block, EVENT_CHECK_IN, date.toEpochDay())
                }
            }
        }

        habits.filter { it.isEnabled && !it.isFlexibleTime && it.startMinute != null }.forEach { habit ->
            val days = habit.daysOfWeekCsv.split(',').mapNotNull(String::toIntOrNull).toSet()
            for (offset in 0..7) {
                val date = today.plusDays(offset.toLong())
                if (date.dayOfWeek.value !in days) continue
                val minute = habit.startMinute ?: continue
                val at = LocalDateTime.of(date, LocalTime.of(minute / 60, minute % 60))
                if (at.isAfter(now)) {
                    val intent = Intent(context, BlockAlarmReceiver::class.java).apply {
                        action = "com.plannin.HABIT_ALARM.${habit.id}.${date.toEpochDay()}"
                        putExtra(EXTRA_EVENT_TYPE, EVENT_HABIT)
                        putExtra(EXTRA_TITLE, habit.title)
                        putExtra(EXTRA_CHANNEL_ID, habit.channelId)
                    }
                    val pi = PendingIntent.getBroadcast(context, intent.action.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    setAlarm(alarmManager, at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), pi)
                }
            }
        }
    }

    private fun schedule(manager: AlarmManager, context: Context, millis: Long, block: TimeBlockEntity, event: String, epochDay: Long) {
        val intent = Intent(context, BlockAlarmReceiver::class.java).apply {
            action = "com.plannin.$event.${block.id}.$epochDay"
            putExtra(EXTRA_EVENT_TYPE, event)
            putExtra(EXTRA_BLOCK_ID, block.id)
            putExtra(EXTRA_PROJECT_ID, block.projectId)
            putExtra(EXTRA_TITLE, block.title)
        }
        val pending = PendingIntent.getBroadcast(context, intent.action.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        setAlarm(manager, millis, pending)
    }

    private fun setAlarm(manager: AlarmManager, millis: Long, pending: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
            } else {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
            }
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
        }
    }
}
