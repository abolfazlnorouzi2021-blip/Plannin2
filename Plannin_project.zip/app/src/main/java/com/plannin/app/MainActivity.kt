package com.plannin.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.plannin.app.data.local.PlanninDatabase
import com.plannin.app.ui.PlanninRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = PlanninDatabase.get(applicationContext)
        setContent { PlanninRoot(db) }
    }
}
