package com.plannin.app.ui

import com.plannin.app.data.local.*
import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

object BackupJson {
    suspend fun export(db: PlanninDatabase): String {
        val root = JSONObject()
            .put("schemaVersion", 2)
            .put("app", "Plannin")
            .put("exportedAt", System.currentTimeMillis())

        root.put("goals", JSONArray().apply {
            db.goalDao().getAllSnapshot().forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("description", it.description).put("targetDateEpochDay", it.targetDateEpochDay).put("createdAt", it.createdAt)) }
        })
        root.put("projects", JSONArray().apply {
            db.projectDao().getAll().forEach { p ->
                put(JSONObject().put("id", p.id).put("goalId", p.goalId).put("name", p.name).put("priority", p.priority)
                    .put("colorHex", p.colorHex).put("icon", p.icon).put("longTermGoal", p.longTermGoal).put("status", p.status)
                    .put("sortOrder", p.sortOrder).put("externalId", p.externalId).put("syncStatus", p.syncStatus)
                    .put("createdAt", p.createdAt).put("updatedAt", p.updatedAt))
            }
        })
        root.put("tasks", JSONArray().apply {
            db.taskDao().getAllSnapshot().forEach { t ->
                put(JSONObject().put("id", t.id).put("projectId", t.projectId).put("title", t.title).put("status", t.status)
                    .put("estimatedMinutes", t.estimatedMinutes).put("repeatRule", t.repeatRule).put("checklistJson", t.checklistJson)
                    .put("note", t.note).put("sortOrder", t.sortOrder).put("externalId", t.externalId).put("syncStatus", t.syncStatus)
                    .put("createdAt", t.createdAt).put("completedAt", t.completedAt))
            }
        })
        root.put("timeBlocks", JSONArray().apply {
            db.timeBlockDao().getAllSnapshot().forEach { b ->
                put(JSONObject().put("id", b.id).put("projectId", b.projectId).put("taskId", b.taskId).put("title", b.title)
                    .put("dayOfWeekIso", b.dayOfWeekIso).put("startMinute", b.startMinute).put("endMinute", b.endMinute)
                    .put("blockType", b.blockType).put("isOptional", b.isOptional).put("isEnabled", b.isEnabled)
                    .put("startNotification", b.startNotification).put("checkInNotification", b.checkInNotification)
                    .put("softReminder", b.softReminder).put("isFlexible", b.isFlexible).put("externalId", b.externalId).put("syncStatus", b.syncStatus))
            }
        })
        root.put("habits", JSONArray().apply {
            db.habitDao().getAllSnapshot().forEach { h ->
                put(JSONObject().put("id", h.id).put("title", h.title).put("daysOfWeekCsv", h.daysOfWeekCsv)
                    .put("startMinute", h.startMinute).put("durationMinutes", h.durationMinutes).put("minimumMinutes", h.minimumMinutes)
                    .put("channelId", h.channelId).put("isFlexibleTime", h.isFlexibleTime).put("isEnabled", h.isEnabled))
            }
        })
        root.put("habitLogs", JSONArray().apply {
            db.habitDao().getAllLogs().forEach { h -> put(JSONObject().put("id", h.id).put("habitId", h.habitId).put("dateEpochDay", h.dateEpochDay).put("completedMinutes", h.completedMinutes).put("completedAt", h.completedAt).put("note", h.note)) }
        })
        root.put("journal", JSONArray().apply {
            db.journalDao().getAllSnapshot().forEach { j -> put(JSONObject().put("id", j.id).put("body", j.body).put("moodEmoji", j.moodEmoji).put("projectId", j.projectId).put("entryType", j.entryType).put("metadataJson", j.metadataJson).put("createdAt", j.createdAt)) }
        })
        root.put("decisionLogs", JSONArray().apply {
            db.decisionLogDao().getAllSnapshot().forEach { d -> put(JSONObject().put("id", d.id).put("projectId", d.projectId).put("taskId", d.taskId).put("reason", d.reason).put("decision", d.decision).put("note", d.note).put("createdAt", d.createdAt)) }
        })
        root.put("sessions", JSONArray().apply {
            db.sessionDao().getAllSnapshot().forEach { x ->
                put(JSONObject().put("id", x.id).put("blockId", x.blockId).put("projectId", x.projectId).put("title", x.title)
                    .put("dateEpochDay", x.dateEpochDay).put("plannedStartMinute", x.plannedStartMinute).put("plannedEndMinute", x.plannedEndMinute)
                    .put("actualStartMillis", x.actualStartMillis).put("actualEndMillis", x.actualEndMillis).put("totalPausedMillis", x.totalPausedMillis)
                    .put("pausedAtMillis", x.pausedAtMillis).put("status", x.status).put("checkInNote", x.checkInNote).put("missedReason", x.missedReason))
            }
        })
        return root.toString(2)
    }
    suspend fun import(db: PlanninDatabase, raw: String) {
        val root = JSONObject(raw)
        require(root.optInt("schemaVersion", -1) in 1..2) { "نسخه فایل پشتیبان پشتیبانی نمی‌شود." }
        db.withTransaction {
            val goals = root.optJSONArray("goals")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                GoalEntity(j.getString("id"), j.getString("title"), j.optString("description"), j.nullableLong("targetDateEpochDay"), j.optLong("createdAt", System.currentTimeMillis()))
            } }.orEmpty()
            db.goalDao().upsertAll(goals)

            val projects = root.optJSONArray("projects")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                ProjectEntity(j.getString("id"), j.nullableString("goalId"), j.getString("name"), j.optInt("priority", 5), j.optString("colorHex", "#718096"), j.optString("icon", "📌"), j.optString("longTermGoal"), j.optString("status", "ACTIVE"), j.optInt("sortOrder"), j.nullableString("externalId"), j.optString("syncStatus", "LOCAL_ONLY"), j.optLong("createdAt", System.currentTimeMillis()), j.optLong("updatedAt", System.currentTimeMillis()))
            } }.orEmpty()
            db.projectDao().upsertAll(projects)

            val tasks = root.optJSONArray("tasks")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                TaskEntity(j.getString("id"), j.getString("projectId"), j.getString("title"), j.optString("status", "TODO"), j.optInt("estimatedMinutes", 30), j.optString("repeatRule", "NONE"), j.optString("checklistJson", "[]"), j.optString("note"), j.optInt("sortOrder"), j.nullableString("externalId"), j.optString("syncStatus", "LOCAL_ONLY"), j.optLong("createdAt", System.currentTimeMillis()), j.nullableLong("completedAt"))
            } }.orEmpty()
            db.taskDao().upsertAll(tasks)

            val blocks = root.optJSONArray("timeBlocks")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                TimeBlockEntity(j.getString("id"), j.nullableString("projectId"), j.nullableString("taskId"), j.getString("title"), j.optInt("dayOfWeekIso", 1), j.optInt("startMinute"), j.optInt("endMinute"), j.optString("blockType", "PROJECT"), j.optBoolean("isOptional"), j.optBoolean("isEnabled", true), j.optBoolean("startNotification", true), j.optBoolean("checkInNotification", true), j.optBoolean("softReminder"), j.optBoolean("isFlexible"), j.nullableString("externalId"), j.optString("syncStatus", "LOCAL_ONLY"))
            } }.orEmpty()
            db.timeBlockDao().upsertAll(blocks)

            val habits = root.optJSONArray("habits")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                HabitEntity(j.getString("id"), j.getString("title"), j.optString("daysOfWeekCsv", "1,2,3,4,5,6,7"), j.nullableInt("startMinute"), j.optInt("durationMinutes", 5), j.optInt("minimumMinutes", 5), j.optString("channelId"), j.optBoolean("isFlexibleTime"), j.optBoolean("isEnabled", true))
            } }.orEmpty()
            db.habitDao().upsertAll(habits)

            val habitLogs = root.optJSONArray("habitLogs")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                HabitLogEntity(j.getString("id"), j.getString("habitId"), j.optLong("dateEpochDay"), j.optInt("completedMinutes"), j.optLong("completedAt", System.currentTimeMillis()), j.optString("note"))
            } }.orEmpty()
            db.habitDao().upsertLogs(habitLogs)

            val journals = root.optJSONArray("journal")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                JournalEntryEntity(j.getString("id"), j.optString("body"), j.optString("moodEmoji", "🙂"), j.nullableString("projectId"), j.optString("entryType", "MANUAL"), j.optString("metadataJson", "{}"), j.optLong("createdAt", System.currentTimeMillis()))
            } }.orEmpty()
            db.journalDao().insertAll(journals)

            val decisions = root.optJSONArray("decisionLogs")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                DecisionLogEntity(j.getString("id"), j.nullableString("projectId"), j.nullableString("taskId"), j.optString("reason"), j.optString("decision"), j.optString("note"), j.optLong("createdAt", System.currentTimeMillis()))
            } }.orEmpty()
            db.decisionLogDao().insertAll(decisions)

            val sessions = root.optJSONArray("sessions")?.let { array -> (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                SessionEntity(j.getString("id"), j.getString("blockId"), j.nullableString("projectId"), j.getString("title"),
                    j.optLong("dateEpochDay"), j.optInt("plannedStartMinute"), j.optInt("plannedEndMinute"), j.optLong("actualStartMillis"),
                    j.nullableLong("actualEndMillis"), j.optLong("totalPausedMillis"), j.nullableLong("pausedAtMillis"),
                    j.optString("status", "COMPLETED"), j.optString("checkInNote"), j.optString("missedReason"))
            } }.orEmpty()
            sessions.forEach { db.sessionDao().upsert(it) }
        }
    }

    private fun JSONObject.nullableString(key: String): String? = if (isNull(key) || !has(key)) null else optString(key).takeIf { it != "null" }
    private fun JSONObject.nullableLong(key: String): Long? = if (isNull(key) || !has(key)) null else optLong(key)
    private fun JSONObject.nullableInt(key: String): Int? = if (isNull(key) || !has(key)) null else optInt(key)

}
