package com.plannin.app.support

import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** Android ICU uses the Persian calendar for the fa-IR locale on supported Android releases. */
object JalaliDateFormatter {
    fun today(): String = DateFormat.getDateInstance(DateFormat.FULL, Locale("fa", "IR")).format(Date())
}
