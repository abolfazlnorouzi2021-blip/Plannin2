package com.plannin.app.data.local

object SeedData {
    const val GOAL_ID = "goal_financial_independence"
    const val TRADING = "project_trading"
    const val FINANCE = "project_finance_literacy"
    const val ENGLISH = "project_english"
    const val AWARENESS = "project_awareness"
    const val UNIVERSITY = "project_university"

    val goals = listOf(
        GoalEntity(
            id = GOAL_ID,
            title = "ساختن پایه مالی و رشد فردی",
            description = "پیشرفت پایدار در معامله‌گری، سواد مالی، زبان، آگاهی و تحصیلات"
        )
    )

    val projects = listOf(
        ProjectEntity(TRADING, GOAL_ID, "تریدینگ", 1, "#245A43", "📈", "تسلط بر سیستم معاملاتی و رسیدن به عملکرد پایدار", sortOrder = 1),
        ProjectEntity(FINANCE, GOAL_ID, "سواد مالی", 2, "#3478B8", "💰", "تقویت سواد مالی، سرمایه‌گذاری و تصمیم‌گیری اقتصادی", sortOrder = 2),
        ProjectEntity(ENGLISH, GOAL_ID, "یادگیری زبان انگلیسی", 3, "#D98236", "🇬🇧", "توانایی استفاده مستقل از منابع و آموزش‌های انگلیسی", sortOrder = 3),
        ProjectEntity(AWARENESS, GOAL_ID, "افزایش آگاهی و انرژی", 4, "#8063B4", "🧠", "افزایش آگاهی، آرامش و انرژی روزانه", sortOrder = 4),
        ProjectEntity(UNIVERSITY, GOAL_ID, "دانشگاه؛ مدیریت مالی", 5, "#718096", "🎓", "یادگیری کاربردی مدیریت مالی و اقتصاد", sortOrder = 5)
    )

    private fun task(
        id: String, project: String, title: String, order: Int,
        status: String = "TODO", minutes: Int = 30, repeat: String = "NONE", note: String = ""
    ) = TaskEntity(
        id = id, projectId = project, title = title, sortOrder = order,
        status = status, estimatedMinutes = minutes, repeatRule = repeat, note = note
    )

    val tasks = listOf(
        task("trading_price_action", TRADING, "آموزش پرایس اکشن", 1, minutes = 45),
        task("trading_strategy", TRADING, "استراتژی‌نویسی", 2, "DONE", 0),
        task("trading_backtest", TRADING, "بک‌تست‌گیری", 3, "DONE", 0),
        task("trading_plan", TRADING, "تریدینگ‌پلن‌نویسی", 4, "IN_PROGRESS", 60),
        task("trading_forward", TRADING, "فوروارد تست", 5, minutes = 60, note = "پس از تکمیل پلن و تأیید مربی"),

        task("finance_book", FINANCE, "مطالعه کتاب «فقر احمق می‌کند»", 1, minutes = 30, repeat = "DAILY"),
        task("finance_bookcast", FINANCE, "خلاصه کتاب / بوک‌کست", 2, minutes = 30),
        task("finance_audio_success", FINANCE, "کتاب صوتی «مدیریت مالی موفق»", 3, minutes = 30),
        task("finance_audio_capitalism", FINANCE, "کتاب صوتی «سرمایه‌داری و آزادی»", 4, minutes = 30),

        task("english_class", ENGLISH, "کلاس آنلاین انگلیسی", 1, minutes = 60, repeat = "WEEKLY"),
        task("english_sentences", ENGLISH, "تمرین جمله‌سازی؛ حداقل ۳۰ دقیقه", 2, minutes = 30, repeat = "WEEKLY"),
        task("english_grammar", ENGLISH, "آموزش گرامر از یوتیوب", 3, minutes = 30, repeat = "WEEKLY"),
        task("english_homework", ENGLISH, "انجام تکالیف کلاس", 4, minutes = 30, repeat = "WEEKLY"),

        task("awareness_meditation", AWARENESS, "مدیتیشن؛ حداقل ۵ دقیقه", 1, minutes = 5, repeat = "DAILY"),
        task("awareness_podcast", AWARENESS, "پادکست «این نقطه»", 2, minutes = 30, repeat = "WEEKLY"),
        task("awareness_video_1", AWARENESS, "مزدافر مومنی ۱؛ مشاهده و شعور", 3, minutes = 30),
        task("awareness_video_2", AWARENESS, "مزدافر مومنی ۲؛ گذر از ذهن", 4, minutes = 30),
        task("awareness_video_3", AWARENESS, "مزدافر مومنی ۳؛ آفرینش", 5, minutes = 30),
        task("awareness_video_4", AWARENESS, "مزدافر مومنی ۴؛ انرژی‌ها و چاکرا", 6, minutes = 30),
        task("awareness_video_5", AWARENESS, "مزدافر مومنی ۵؛ تابش مهر", 7, minutes = 30),

        task("uni_finance_book", UNIVERSITY, "مطالعه کتاب مدیریت مالی + جمع‌بندی با AI", 1, minutes = 60),
        task("uni_microeconomics_video", UNIVERSITY, "آموزش اقتصاد خرد دکتر صادقیان", 2, minutes = 45),
        task("uni_microeconomics_book", UNIVERSITY, "مرور کتاب اقتصاد خرد", 3, minutes = 30)
    )

    private fun block(
        id: String, title: String, day: Int, start: Int, end: Int,
        project: String? = null, type: String = "PROJECT", optional: Boolean = false,
        flexible: Boolean = false, startAlert: Boolean = false, checkIn: Boolean = false
    ) = TimeBlockEntity(
        id = id, projectId = project, title = title, dayOfWeekIso = day,
        startMinute = start, endMinute = end, blockType = type,
        isOptional = optional, isFlexible = flexible,
        startNotification = startAlert, checkInNotification = checkIn,
        softReminder = false
    )

    // ISO day values: Monday=1, Tuesday=2, Wednesday=3, Thursday=4, Friday=5, Saturday=6, Sunday=7.
    val blocks = buildList {
        // Trading: every day except Saturday.
        listOf(7, 1, 2, 3, 4, 5).forEach { day ->
            add(block("trading_$day", "شیفت تریدینگ", day, 8 * 60, 12 * 60, TRADING))
        }
        // Financial literacy: Sunday, Monday, Wednesday, Friday.
        listOf(7, 1, 3, 5).forEach { day ->
            add(block("lunch_break_$day", "استراحت و ناهار", day, 12 * 60, 12 * 60 + 15, type = "PERSONAL_FREE", startAlert = false, checkIn = false))
            add(block("finance_$day", "شیفت سواد مالی", day, 12 * 60 + 15, 14 * 60, FINANCE))
        }
        // Online English class: Sunday and Friday.
        listOf(7, 5).forEach { day ->
            add(block("english_class_$day", "کلاس آنلاین انگلیسی + تکالیف", day, 14 * 60, 15 * 60, ENGLISH))
        }
        // Awareness is an evening flexible slot; the app never fires an exact-time alarm for it.
        (1..7).forEach { day ->
            add(block("awareness_flexible_$day", "بلوک شناور آگاهی و انرژی", day, 0, 0, AWARENESS, flexible = true, startAlert = false, checkIn = false))
        }

        // University timetable.
        add(block("uni_sat_ops", "تحقیق در عملیات ۱", 6, 10 * 60, 12 * 60, UNIVERSITY, "UNIVERSITY", startAlert = false, checkIn = false))
        add(block("uni_sat_stats", "آمار", 6, 12 * 60, 14 * 60, UNIVERSITY, "UNIVERSITY", startAlert = false, checkIn = false))
        add(block("free_sat_library", "زمان آزاد شخصی / کتابخانه", 6, 14 * 60, 15 * 60, type = "PERSONAL_FREE", startAlert = false, checkIn = false))
        add(block("uni_sat_math", "ریاضیات", 6, 15 * 60, 17 * 60, UNIVERSITY, "UNIVERSITY", startAlert = false, checkIn = false))
        add(block("uni_mon_micro", "اقتصاد خرد", 1, 16 * 60, 18 * 60, UNIVERSITY, "UNIVERSITY", startAlert = false, checkIn = false))
        add(block("uni_thu_finance", "مدیریت مالی", 4, 13 * 60, 17 * 60, UNIVERSITY, "UNIVERSITY", startAlert = false, checkIn = false))
        add(block("uni_thu_wasaya", "وصایای امام؛ حضور اختیاری", 4, 17 * 60, 19 * 60, UNIVERSITY, "OPTIONAL_CLASS", optional = true, startAlert = false, checkIn = false))
        // Sunday after 15:00 is protected recovery / leisure time.
        add(block("sunday_rest", "استراحت مطلق و تفریح", 7, 15 * 60, 23 * 60 + 59, type = "PERSONAL_FREE", startAlert = false, checkIn = false))
    }

    val habits = listOf(
        HabitEntity(
            id = "habit_meditation", title = "مدیتیشن", daysOfWeekCsv = "1,2,3,4,5,6,7",
            startMinute = null, durationMinutes = 5, minimumMinutes = 5,
            channelId = "habit_meditation", isFlexibleTime = true
        ),
        HabitEntity(
            id = "habit_workout", title = "ورزش", daysOfWeekCsv = "7,2,4",
            startMinute = 7 * 60, durationMinutes = 30, minimumMinutes = 30,
            channelId = "habit_workout", isFlexibleTime = true
        )
    )
}
