package com.plannin.app.scheduler

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object NotificationChannels {
    const val BLOCK_START = "block_start"
    const val BLOCK_CHECK_IN = "block_check_in"
    const val MEDITATION = "habit_meditation"
    const val WORKOUT = "habit_workout"

    fun create(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        val channels = listOf(
            NotificationChannel(BLOCK_START, "شروع تایم‌بلاک‌ها", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اعلان شروع پروژه و زمان تمرکز"
            },
            NotificationChannel(BLOCK_CHECK_IN, "چک‌این پایان تایم‌بلاک", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "ثبت عملکرد و وضعیت کارهای بلوک"
            },
            NotificationChannel(MEDITATION, "یادآوری مدیتیشن", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "یادآوری انعطاف‌پذیر عادت مدیتیشن"
            },
            NotificationChannel(WORKOUT, "یادآوری ورزش", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "یادآوری ورزش در روزهای یکشنبه، سه‌شنبه و پنجشنبه"
            }
        )
        manager.createNotificationChannels(channels)
    }
}
