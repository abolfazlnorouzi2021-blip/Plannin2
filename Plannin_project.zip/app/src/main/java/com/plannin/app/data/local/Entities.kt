package com.plannin.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String = "",
    val targetDateEpochDay: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "projects", indices = [Index("priority"), Index("goalId")])
data class ProjectEntity(
    @PrimaryKey val id: String,
    val goalId: String? = null,
    val name: String,
    val priority: Int,
    val colorHex: String,
    val icon: String,
    val longTermGoal: String = "",
    val status: String = "ACTIVE", // ACTIVE, PAUSED, COMPLETED
    val sortOrder: Int = 0,
    val externalId: String? = null,
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks", indices = [Index("projectId"), Index("status")])
data class TaskEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val title: String,
    val status: String = "TODO", // TODO, IN_PROGRESS, DONE
    val estimatedMinutes: Int = 30,
    val repeatRule: String = "NONE", // NONE, DAILY, WEEKLY
    val checklistJson: String = "[]",
    val note: String = "",
    val sortOrder: Int = 0,
    val externalId: String? = null,
    val syncStatus: String = "LOCAL_ONLY",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

@Entity(tableName = "time_blocks", indices = [Index("projectId"), Index("dayOfWeekIso"), Index("blockType")])
data class TimeBlockEntity(
    @PrimaryKey val id: String,
    val projectId: String? = null,
    val taskId: String? = null,
    val title: String,
    val dayOfWeekIso: Int, // ISO: Monday=1 ... Sunday=7
    val startMinute: Int,
    val endMinute: Int,
    val blockType: String = "PROJECT", // PROJECT, UNIVERSITY, PERSONAL_FREE, OPTIONAL_CLASS
    val isOptional: Boolean = false,
    val isEnabled: Boolean = true,
    val startNotification: Boolean = true,
    val checkInNotification: Boolean = true,
    val softReminder: Boolean = false,
    val isFlexible: Boolean = false,
    val externalId: String? = null,
    val syncStatus: String = "LOCAL_ONLY"
)

@Entity(tableName = "habits", indices = [Index("isEnabled")])
data class HabitEntity(
    @PrimaryKey val id: String,
    val title: String,
    val daysOfWeekCsv: String,
    val startMinute: Int? = null,
    val durationMinutes: Int = 5,
    val minimumMinutes: Int = 5,
    val channelId: String,
    val isFlexibleTime: Boolean = false,
    val isEnabled: Boolean = true
)

@Entity(tableName = "habit_logs", indices = [Index("habitId"), Index("dateEpochDay")])
data class HabitLogEntity(
    @PrimaryKey val id: String,
    val habitId: String,
    val dateEpochDay: Long,
    val completedMinutes: Int,
    val completedAt: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "journal_entries", indices = [Index("createdAt"), Index("projectId")])
data class JournalEntryEntity(
    @PrimaryKey val id: String,
    val body: String,
    val moodEmoji: String = "🙂",
    val projectId: String? = null,
    val entryType: String = "MANUAL", // MANUAL, DAILY_AUTO, NIGHT_CHECK_IN
    val metadataJson: String = "{}",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "decision_logs", indices = [Index("projectId"), Index("createdAt")])
data class DecisionLogEntity(
    @PrimaryKey val id: String,
    val projectId: String?,
    val taskId: String? = null,
    val reason: String,
    val decision: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)


@Entity(tableName = "sessions", indices = [Index("dateEpochDay"), Index("blockId"), Index("status")])
data class SessionEntity(
    @PrimaryKey val id: String,
    val blockId: String,
    val projectId: String?,
    val title: String,
    val dateEpochDay: Long,
    val plannedStartMinute: Int,
    val plannedEndMinute: Int,
    val actualStartMillis: Long,
    val actualEndMillis: Long? = null,
    val totalPausedMillis: Long = 0L,
    val pausedAtMillis: Long? = null,
    val status: String = "RUNNING", // RUNNING, PAUSED, COMPLETED, MISSED
    val checkInNote: String = "",
    val missedReason: String = ""
)
