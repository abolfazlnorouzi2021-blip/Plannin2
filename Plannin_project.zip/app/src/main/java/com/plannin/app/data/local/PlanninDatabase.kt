package com.plannin.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Database(
    entities = [
        GoalEntity::class, ProjectEntity::class, TaskEntity::class, TimeBlockEntity::class,
        HabitEntity::class, HabitLogEntity::class, JournalEntryEntity::class, DecisionLogEntity::class, SessionEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class PlanninDatabase : RoomDatabase() {
    abstract fun goalDao(): GoalDao
    abstract fun projectDao(): ProjectDao
    abstract fun taskDao(): TaskDao
    abstract fun timeBlockDao(): TimeBlockDao
    abstract fun habitDao(): HabitDao
    abstract fun journalDao(): JournalDao
    abstract fun decisionLogDao(): DecisionLogDao
    abstract fun sessionDao(): SessionDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS sessions (id TEXT NOT NULL, blockId TEXT NOT NULL, projectId TEXT, title TEXT NOT NULL, dateEpochDay INTEGER NOT NULL, plannedStartMinute INTEGER NOT NULL, plannedEndMinute INTEGER NOT NULL, actualStartMillis INTEGER NOT NULL, actualEndMillis INTEGER, totalPausedMillis INTEGER NOT NULL, pausedAtMillis INTEGER, status TEXT NOT NULL, checkInNote TEXT NOT NULL, missedReason TEXT NOT NULL, PRIMARY KEY(id))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sessions_dateEpochDay ON sessions(dateEpochDay)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sessions_blockId ON sessions(blockId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sessions_status ON sessions(status)")
            }
        }
        @Volatile private var INSTANCE: PlanninDatabase? = null

        fun get(context: Context): PlanninDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                PlanninDatabase::class.java,
                "plannin.db"
            ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}

suspend fun PlanninDatabase.seedIfEmpty() = withContext(Dispatchers.IO) {
    withTransaction {
        if (projectDao().getAll().isEmpty()) {
            goalDao().upsertAll(SeedData.goals)
            projectDao().insertAll(SeedData.projects)
            taskDao().insertAll(SeedData.tasks)
            timeBlockDao().insertAll(SeedData.blocks)
            habitDao().insertAll(SeedData.habits)
        }
    }
}
