package com.plannin.app.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.plannin.app.data.local.*
import com.plannin.app.domain.PlannerRules
import com.plannin.app.scheduler.AlarmScheduler
import com.plannin.app.scheduler.NotificationChannels
import com.plannin.app.support.JalaliDateFormatter
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

private enum class AppTab(val title: String) {
    HOME("خانه"), PROJECTS("پروژه‌ها"), REPORTS("گزارش‌ها"), JOURNAL("ژورنال"), SETTINGS("تنظیمات")
}

@Composable
fun PlanninRoot(db: PlanninDatabase) {
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var selectedProject by remember { mutableStateOf<ProjectEntity?>(null) }
    var darkTheme by remember { mutableStateOf(true) }
    val projects by db.projectDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val tasks by db.taskDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val blocks by db.timeBlockDao().observeEnabled().collectAsStateWithLifecycle(initialValue = emptyList())
    val journals by db.journalDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val habits by db.habitDao().observeEnabled().collectAsStateWithLifecycle(initialValue = emptyList())
    val todayEpochDay = remember { LocalDate.now().toEpochDay() }
    val habitLogs by db.habitDao().logsForDay(todayEpochDay).collectAsStateWithLifecycle(initialValue = emptyList())
    val todaySessions by db.sessionDao().observeForDay(todayEpochDay).collectAsStateWithLifecycle(initialValue = emptyList())
    val activeSession by db.sessionDao().observeActive().collectAsStateWithLifecycle(initialValue = null)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Toast.makeText(context, if (granted) "اعلان‌ها فعال شدند" else "مجوز اعلان داده نشد", Toast.LENGTH_SHORT).show()
    }
    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val json = BackupJson.export(db)
                context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(context, "فایل پشتیبان ذخیره شد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("فایل قابل خواندن نیست")
                    BackupJson.import(db, raw)
                    AlarmScheduler.scheduleUpcoming(context, db.timeBlockDao().getEnabled(), db.habitDao().getEnabled())
                    Toast.makeText(context, "بازیابی پشتیبان انجام شد", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "بازیابی ناموفق: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val colors = darkColorScheme(
        primary = Color(0xFFC9A961),
        onPrimary = Color(0xFF0A0A0B),
        secondary = Color(0xFFE8D5B5),
        background = Color(0xFF0A0A0B),
        surface = Color(0xFF141416),
        surfaceVariant = Color(0xFF1C1C20),
        onBackground = Color(0xFFFAFAF8),
        onSurface = Color(0xFFFAFAF8),
        onSurfaceVariant = Color(0xFFB0B0B8),
        outline = Color(0x33C9A961)
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = colors) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    if (activeSession == null) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        AppTab.entries.forEach { tab ->
                            val icon = when (tab) {
                                AppTab.HOME -> Icons.Default.Home
                                AppTab.PROJECTS -> Icons.Default.FolderOpen
                                AppTab.REPORTS -> Icons.Default.BarChart
                                AppTab.JOURNAL -> Icons.Default.MenuBook
                                AppTab.SETTINGS -> Icons.Default.Settings
                            }
                            NavigationBarItem(
                                selected = selectedTab == tab && selectedProject == null,
                                onClick = { selectedProject = null; selectedTab = tab },
                                icon = { Icon(icon, contentDescription = tab.title) },
                                label = { Text(tab.title, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            ) { padding ->
                if (selectedProject != null) {
                    ProjectDetailScreen(
                        project = selectedProject!!,
                        tasks = tasks.filter { it.projectId == selectedProject!!.id },
                        onBack = { selectedProject = null },
                        onTaskStatus = { taskId, done ->
                            scope.launch { db.taskDao().updateStatus(taskId, if (done) "DONE" else "TODO", if (done) System.currentTimeMillis() else null) }
                        },
                        onAddTask = { title ->
                            scope.launch {
                                val count = tasks.count { it.projectId == selectedProject!!.id }
                                db.taskDao().upsert(TaskEntity(UUID.randomUUID().toString(), selectedProject!!.id, title, sortOrder = count + 1))
                            }
                        },
                        modifier = Modifier.padding(padding)
                    )
                } else when (selectedTab) {
                    AppTab.HOME -> HomeScreen(
                        projects, tasks, blocks, habits, habitLogs, todaySessions, activeSession,
                        modifier = Modifier.padding(padding),
                        onOpenProject = { selectedProject = it },
                        onLogHabit = { habitId, minutes ->
                            scope.launch {
                                db.habitDao().insertLog(HabitLogEntity(UUID.randomUUID().toString(), habitId, todayEpochDay, minutes))
                            }
                        },
                        onStartBlock = { block ->
                            if (activeSession == null) scope.launch {
                                if (db.sessionDao().getActiveSession() == null) db.sessionDao().upsert(SessionEntity(
                                    id = UUID.randomUUID().toString(), blockId = block.id, projectId = block.projectId,
                                    title = block.title, dateEpochDay = todayEpochDay,
                                    plannedStartMinute = block.startMinute, plannedEndMinute = block.endMinute,
                                    actualStartMillis = System.currentTimeMillis()
                                ))
                            }
                        },
                        onPauseSession = { session -> scope.launch {
                            db.sessionDao().upsert(session.copy(status = "PAUSED", pausedAtMillis = System.currentTimeMillis()))
                        } },
                        onResumeSession = { session -> scope.launch {
                            val paused = (System.currentTimeMillis() - (session.pausedAtMillis ?: System.currentTimeMillis())).coerceAtLeast(0L)
                            db.sessionDao().upsert(session.copy(status = "RUNNING", pausedAtMillis = null, totalPausedMillis = session.totalPausedMillis + paused))
                        } },
                        onEndSession = { session, note -> scope.launch {
                            val now = System.currentTimeMillis()
                            val extraPause = if (session.status == "PAUSED") (now - (session.pausedAtMillis ?: now)).coerceAtLeast(0L) else 0L
                            db.sessionDao().upsert(session.copy(status = "COMPLETED", actualEndMillis = now, pausedAtMillis = null, totalPausedMillis = session.totalPausedMillis + extraPause, checkInNote = note))
                        } }
                    )
                    AppTab.PROJECTS -> ProjectsScreen(projects, tasks, onOpenProject = { selectedProject = it }, modifier = Modifier.padding(padding))
                    AppTab.REPORTS -> ReportsScreen(projects, tasks, modifier = Modifier.padding(padding))
                    AppTab.JOURNAL -> JournalScreen(db, projects, journals, modifier = Modifier.padding(padding))
                    AppTab.SETTINGS -> SettingsScreen(
                        darkTheme = darkTheme,
                        onDarkThemeChange = { darkTheme = it },
                        onNotificationPermission = {
                            if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            else Toast.makeText(context, "اعلان‌ها از تنظیمات اندروید قابل مدیریت هستند", Toast.LENGTH_SHORT).show()
                        },
                        onExactAlarmSettings = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply { data = Uri.parse("package:${context.packageName}") })
                            }
                        },
                        onExport = { createBackup.launch("plannin-backup.json") },
                        onImport = { openBackup.launch(arrayOf("application/json", "text/json")) },
                        onReschedule = {
                            scope.launch { AlarmScheduler.scheduleUpcoming(context, db.timeBlockDao().getEnabled(), db.habitDao().getEnabled()) }
                            Toast.makeText(context, "زمان‌بندی اعلان‌ها بازسازی شد", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.padding(padding)
                    )
                }
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            if (subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        if (action != null) action()
    }
}

@Composable
private fun HomeScreen(
    projects: List<ProjectEntity>, tasks: List<TaskEntity>, blocks: List<TimeBlockEntity>, habits: List<HabitEntity>, habitLogs: List<HabitLogEntity>,
    todaySessions: List<SessionEntity>, activeSession: SessionEntity?,
    modifier: Modifier = Modifier, onOpenProject: (ProjectEntity) -> Unit, onLogHabit: (String, Int) -> Unit,
    onStartBlock: (TimeBlockEntity) -> Unit, onPauseSession: (SessionEntity) -> Unit,
    onResumeSession: (SessionEntity) -> Unit, onEndSession: (SessionEntity, String) -> Unit
) {
    if (activeSession != null) {
        FocusModeScreen(
            session = activeSession, modifier = modifier,
            onPause = { onPauseSession(activeSession) },
            onResume = { onResumeSession(activeSession) },
            onEnd = { note -> onEndSession(activeSession, note) }
        )
        return
    }
    val now = LocalTime.now()
    val day = LocalDate.now().dayOfWeek.value
    val nowMinute = now.hour * 60 + now.minute
    val currentTimeBlock = blocks.firstOrNull {
        it.dayOfWeekIso == day && !it.isFlexible && nowMinute in it.startMinute until it.endMinute
    }
    val activeBlock = currentTimeBlock?.takeIf { it.blockType == "PROJECT" }
    val nextBlock = PlannerRules.nextBlock(blocks, now, day)
    val activeProject = activeBlock?.projectId?.let { id -> projects.firstOrNull { it.id == id } }
    val upcomingProject = nextBlock?.projectId?.let { id -> projects.firstOrNull { it.id == id } }
    val currentProject = activeProject ?: if (currentTimeBlock == null) upcomingProject ?: projects.firstOrNull() else null
    val currentTasks = currentProject?.let { p -> tasks.filter { it.projectId == p.id && it.status != "DONE" } }.orEmpty()
    val workoutToday = habits.firstOrNull { it.id == "habit_workout" && PlannerRules.isHabitDay(it.daysOfWeekCsv, day) }
    val meditation = habits.firstOrNull { it.id == "habit_meditation" }
    val meditationDone = meditation != null && habitLogs.any { it.habitId == meditation.id }
    val workoutDone = workoutToday != null && habitLogs.any { it.habitId == workoutToday.id }
    val mitTask = tasks.firstOrNull { it.status == "IN_PROGRESS" } ?: tasks.firstOrNull { it.status == "TODO" }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ScreenHeader("Plannin", JalaliDateFormatter.today())
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF211D15))) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("MIT امروز · مهم‌ترین کار", color = Color(0xFFC9A961), fontSize = 11.sp, letterSpacing = 1.sp)
                Text(mitTask?.title ?: "امروز را آگاهانه شروع کن", color = Color(0xFFFAFAF8), fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text(mitTask?.let { "${it.estimatedMinutes} دقیقه تخمینی" } ?: "هنوز کاری برای امروز انتخاب نشده", color = Color(0xFFB0B0B8), fontSize = 12.sp)
            }
        }
        Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C20))) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("الان چه کاری باید بکنم؟", color = Color(0xFFE8D5B5), fontSize = 14.sp)
                Text(
                    when {
                        activeProject != null -> activeProject.name
                        currentTimeBlock != null -> currentTimeBlock.title
                        upcomingProject != null -> upcomingProject.name
                        else -> "زمان آزاد شخصی"
                    }, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    when {
                        activeProject != null -> "زمان برنامه‌ریزی‌شده · برای شروع، خودت دکمه شروع را بزن"
                        currentTimeBlock?.blockType == "UNIVERSITY" -> "برنامه ثابت دانشگاه؛ بدون امتیاز منفی برای زمان‌بندی پروژه‌ها"
                        currentTimeBlock?.isOptional == true -> "کلاس اختیاری؛ غیبت بدون جریمه در گزارش"
                        currentTimeBlock?.blockType == "PERSONAL_FREE" -> "زمان آزاد شخصی؛ بدون اعلان و بدون جریمه"
                        upcomingProject != null -> "بلوک بعدی · ${formatMinute(nextBlock!!.startMinute)} تا ${formatMinute(nextBlock.endMinute)}"
                        day == 7 && now.hour >= 15 -> "روز سبک؛ استراحت مطلق و تفریح"
                        else -> "در حال حاضر زمان آزاد شخصی است."
                    }, color = Color(0xFFB0B0B8), fontSize = 13.sp
                )
                if (currentProject != null && (activeProject != null || currentTimeBlock == null)) {
                    val done = tasks.count { it.projectId == currentProject.id && it.status == "DONE" }
                    val total = tasks.count { it.projectId == currentProject.id }
                    LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, color = Color(0xFFC9A961), trackColor = Color(0xFF39332A), modifier = Modifier.fillMaxWidth())
                    Text("$done از $total کار تکمیل شده", color = Color.White, fontSize = 12.sp)
                    Button(onClick = { onOpenProject(currentProject) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC9A961), contentColor = Color(0xFF0A0A0B))) {
                        Text("ورود به پروژه")
                    }
                }
            }
        }
        ScreenHeader("برنامه امروز", "بلوک‌های زمان‌بندی‌شده")
        val todayBlocks = blocks.filter { it.dayOfWeekIso == day && !it.isFlexible }.sortedBy { it.startMinute }
        if (todayBlocks.isEmpty()) EmptyCard("امروز بلوک زمان‌بندی‌شده‌ای نداری.")
        todayBlocks.forEach { block ->
            val project = block.projectId?.let { id -> projects.firstOrNull { it.id == id } }
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(project?.colorHex?.toComposeColor() ?: MaterialTheme.colorScheme.primary, CircleShape))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(block.title, fontWeight = FontWeight.SemiBold)
                    Text("${formatMinute(block.startMinute)} – ${formatMinute(block.endMinute)}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
                if (block.isOptional) Text("اختیاری", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp)
                else if (block.blockType == "PERSONAL_FREE") Text("آزاد", color = MaterialTheme.colorScheme.tertiary, fontSize = 11.sp)
                else {
                    val logged = todaySessions.firstOrNull { it.blockId == block.id && it.status == "COMPLETED" }
                    if (logged != null) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ثبت شد", color = Color(0xFF7BA05B), fontSize = 11.sp)
                            Text("واقعی: ${formatClock(logged.actualStartMillis)}–${formatClock(logged.actualEndMillis ?: logged.actualStartMillis)} · ${formatDuration(((logged.actualEndMillis ?: logged.actualStartMillis) - logged.actualStartMillis - logged.totalPausedMillis).coerceAtLeast(0L))}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                        }
                    } else {
                        TextButton(onClick = { onStartBlock(block) }) { Text("شروع", color = Color(0xFFC9A961)) }
                    }
                }
            }
        }
        ScreenHeader("عادت‌های روزانه")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HabitMiniCard(Icons.Default.Spa, "مدیتیشن", "حداقل ۵ دقیقه", meditationDone, Modifier.weight(1f)) { if (!meditationDone && meditation != null) onLogHabit(meditation.id, meditation.minimumMinutes) }
            HabitMiniCard(Icons.Default.FitnessCenter, "ورزش", if (workoutToday != null) "امروز · ۷:۰۰" else "امروز برنامه ندارد", workoutDone || workoutToday == null, Modifier.weight(1f)) { if (!workoutDone && workoutToday != null) onLogHabit(workoutToday.id, workoutToday.minimumMinutes) }
        }
        if (currentTasks.isNotEmpty()) {
            ScreenHeader("کارهای باقی‌مانده", currentProject?.name)
            currentTasks.take(4).forEach { Text("•  ${it.title}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun FocusModeScreen(
    session: SessionEntity, modifier: Modifier = Modifier, onPause: () -> Unit,
    onResume: () -> Unit, onEnd: (String) -> Unit
) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showEndDialog by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    LaunchedEffect(session.id, session.status) {
        while (true) { nowMillis = System.currentTimeMillis(); delay(1000) }
    }
    val pausedNow = if (session.status == "PAUSED") (nowMillis - (session.pausedAtMillis ?: nowMillis)).coerceAtLeast(0L) else 0L
    val elapsed = (nowMillis - session.actualStartMillis - session.totalPausedMillis - pausedNow).coerceAtLeast(0L)
    val totalSeconds = elapsed / 1000
    val timer = "%02d:%02d:%02d".format(totalSeconds / 3600, (totalSeconds / 60) % 60, totalSeconds % 60)
    Column(
        modifier.fillMaxSize().background(Color(0xFF0A0A0B)).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("FOCUS MODE", color = Color(0xFFB0B0B8), fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(28.dp))
        Text(session.title, color = Color(0xFFFAFAF8), fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(36.dp))
        Text(timer, color = Color(0xFFE8D5B5), fontSize = 48.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(12.dp))
        Text(if (session.status == "PAUSED") "مکث شده" else "زمان واقعی تمرکز", color = Color(0xFFB0B0B8), fontSize = 13.sp)
        Spacer(Modifier.height(48.dp))
        if (session.status == "PAUSED") {
            Button(onClick = onResume, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC9A961), contentColor = Color(0xFF0A0A0B))) { Text("ادامه تمرکز") }
        } else {
            OutlinedButton(onClick = onPause, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE8D5B5))) { Text("مکث") }
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { showEndDialog = true }) { Text("پایان بلوک", color = Color(0xFFC9A961)) }
    }
    if (showEndDialog) {
        AlertDialog(
            onDismissRequest = { showEndDialog = false },
            containerColor = Color(0xFF1C1C20),
            title = { Text("ثبت پایان بلوک", color = Color(0xFFFAFAF8)) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("زمان واقعی تمرکز: $timer", color = Color(0xFFB0B0B8))
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("یادداشت کوتاه (اختیاری)") })
            } },
            confirmButton = { TextButton(onClick = { onEnd(note); showEndDialog = false }) { Text("ثبت و پایان", color = Color(0xFFC9A961)) } },
            dismissButton = { TextButton(onClick = { showEndDialog = false }) { Text("ادامه بلوک") } }
        )
    }
}

private fun formatClock(milliseconds: Long): String = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(milliseconds))

private fun formatDuration(milliseconds: Long): String {
    val minutes = milliseconds / 60000L
    return if (minutes >= 60) "${minutes / 60}س ${minutes % 60}د" else "${minutes}د"
}

@Composable
private fun HabitMiniCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, done: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().clickable { onClick() }.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(if (done) "✓ ثبت‌شده" else "برای ثبت لمس کن", fontSize = 10.sp, color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
private fun ProjectsScreen(projects: List<ProjectEntity>, tasks: List<TaskEntity>, onOpenProject: (ProjectEntity) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenHeader("پروژه‌های من", "اولویت از بالا به پایین")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(projects, key = { it.id }) { project -> ProjectCard(project, tasks.filter { it.projectId == project.id }, Modifier.clickable { onOpenProject(project) }) }
        }
    }
}

@Composable
private fun ProjectCard(project: ProjectEntity, tasks: List<TaskEntity>, modifier: Modifier = Modifier) {
    val done = tasks.count { it.status == "DONE" }
    val progress = if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(project.name, fontWeight = FontWeight.Bold)
                    Text("اولویت ${project.priority}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${(progress * 100).toInt()}٪", color = project.colorHex.toComposeColor(), fontWeight = FontWeight.Bold)
            }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = project.colorHex.toComposeColor())
            Text("$done از ${tasks.size} کار تکمیل شده", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ProjectDetailScreen(
    project: ProjectEntity, tasks: List<TaskEntity>, onBack: () -> Unit,
    onTaskStatus: (String, Boolean) -> Unit, onAddTask: (String) -> Unit, modifier: Modifier = Modifier
) {
    var showAdd by remember { mutableStateOf(false) }
    var newTask by remember { mutableStateOf("") }
    val done = tasks.count { it.status == "DONE" }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت") }
            Column(Modifier.weight(1f)) {
                Text(project.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("اولویت ${project.priority} · ${project.longTermGoal}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = project.colorHex.toComposeColor().copy(alpha = 0.12f)), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("پیشرفت پروژه", fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size }, color = project.colorHex.toComposeColor(), modifier = Modifier.fillMaxWidth())
                Text("$done از ${tasks.size} کار · ${if (tasks.isEmpty()) 0 else done * 100 / tasks.size}٪", fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("چک‌لیست کارها", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            TextButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("کار جدید") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(tasks, key = { it.id }) { task ->
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp)).padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = task.status == "DONE", onCheckedChange = { onTaskStatus(task.id, it) })
                    Column(Modifier.weight(1f)) {
                        Text(task.title, fontWeight = FontWeight.Medium)
                        if (task.note.isNotBlank()) Text(task.note, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                    }
                    Text(if (task.status == "DONE") "انجام‌شده" else if (task.status == "IN_PROGRESS") "در حال انجام" else "باقی‌مانده", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    if (showAdd) AlertDialog(
        onDismissRequest = { showAdd = false },
        title = { Text("افزودن کار") },
        text = { OutlinedTextField(value = newTask, onValueChange = { newTask = it }, label = { Text("عنوان کار") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (newTask.isNotBlank()) onAddTask(newTask.trim()); newTask = ""; showAdd = false }) { Text("افزودن") } },
        dismissButton = { TextButton(onClick = { showAdd = false }) { Text("انصراف") } }
    )
}

@Composable
private fun ReportsScreen(projects: List<ProjectEntity>, tasks: List<TaskEntity>, modifier: Modifier = Modifier) {
    val weightedDone = projects.sumOf { p -> tasks.count { it.projectId == p.id && it.status == "DONE" } * PlannerRules.performanceWeight(p.priority) }
    val weightedTotal = projects.sumOf { p -> tasks.count { it.projectId == p.id } * PlannerRules.performanceWeight(p.priority) }
    val totalPercent = if (weightedTotal == 0.0) 0 else (weightedDone / weightedTotal * 100).toInt()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ScreenHeader("گزارش عملکرد", "نمای کلی بر اساس وضعیت کارهای ثبت‌شده")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("امتیاز وزنی پروژه‌ها", fontWeight = FontWeight.Bold)
                Text("$totalPercent٪", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("وزن تریدینگ بیشتر از دانشگاه در محاسبه لحاظ شده است.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text("پیشرفت به تفکیک پروژه", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        projects.forEach { p ->
            val own = tasks.filter { it.projectId == p.id }
            val percent = if (own.isEmpty()) 0 else own.count { it.status == "DONE" } * 100 / own.size
            Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(15.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.name, fontWeight = FontWeight.Medium)
                    Text("$percent٪", color = p.colorHex.toComposeColor(), fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(progress = { percent / 100f }, color = p.colorHex.toComposeColor(), modifier = Modifier.fillMaxWidth())
            }
        }
        Text("نمودار میله‌ای", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().height(145.dp).background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
            projects.forEach { p ->
                val own = tasks.filter { it.projectId == p.id }
                val percent = if (own.isEmpty()) 0 else own.count { it.status == "DONE" } * 100 / own.size
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Text("$percent", fontSize = 10.sp)
                    Box(Modifier.width(28.dp).height((percent.coerceAtLeast(3) * 0.9f).dp).background(p.colorHex.toComposeColor(), RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)))
                    Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                }
            }
        }
        Text("این گزارش فعلاً بر مبنای وضعیت فعلی کارهاست؛ گزارش‌های تاریخی هفتگی و ماهانه با ثبت رخدادهای هر بلوک در مرحله بعد کامل می‌شوند.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun JournalScreen(db: PlanninDatabase, projects: List<ProjectEntity>, journals: List<JournalEntryEntity>, modifier: Modifier = Modifier) {
    var body by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("متعادل") }
    var projectId by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val filtered = journals.filter { search.isBlank() || it.body.contains(search, ignoreCase = true) }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("ژورنال روزانه", "یادداشت آزاد و ثبت حال‌و‌هوا")
        OutlinedTextField(value = body, onValueChange = { body = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("امروز چه گذشت؟") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("عالی", "خوب", "متعادل", "خسته", "پرفشار").forEach { moodOption ->
                FilterChip(selected = mood == moodOption, onClick = { mood = moodOption }, label = { Text(moodOption) })
            }
        }
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text("پروژه مرتبط: ${projects.firstOrNull { it.id == projectId }?.name ?: "بدون برچسب پروژه"}")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                DropdownMenuItem(text = { Text("بدون برچسب پروژه") }, onClick = { projectId = null; expanded = false })
                projects.forEach { p -> DropdownMenuItem(text = { Text(p.name) }, onClick = { projectId = p.id; expanded = false }) }
            }
        }
        Button(onClick = {
            if (body.isNotBlank()) scope.launch {
                db.journalDao().insert(JournalEntryEntity(UUID.randomUUID().toString(), body.trim(), mood, projectId))
                body = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("ثبت یادداشت") }
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("جستجو در ژورنال") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Text("یادداشت‌های گذشته", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(entry.moodEmoji, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.width(8.dp))
                            Text(if (entry.entryType == "DAILY_AUTO") "خلاصه خودکار" else "یادداشت شخصی", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                        Text(entry.body, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    darkTheme: Boolean, onDarkThemeChange: (Boolean) -> Unit,
    onNotificationPermission: () -> Unit, onExactAlarmSettings: () -> Unit,
    onExport: () -> Unit, onImport: () -> Unit, onReschedule: () -> Unit, modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("تنظیمات", "شخصی‌سازی Plannin")
        SettingRow("تم مشکی و طلایی", "ظاهر اصلی و ثابت Plannin", Icons.Default.DarkMode) { Text("فعال", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
        SettingRow("مجوز اعلان‌ها", "فعال‌سازی یادآوری شروع و پایان بلوک", Icons.Default.Notifications) { TextButton(onClick = onNotificationPermission) { Text("فعال‌سازی") } }
        SettingRow("اعلان دقیق", "دسترسی زمان‌بندی دقیق در اندروید", Icons.Default.Alarm) { TextButton(onClick = onExactAlarmSettings) { Text("تنظیم") } }
        SettingRow("بازسازی زمان‌بندی", "پس از تغییر ساعت یا روزهای بلوک", Icons.Default.Refresh) { TextButton(onClick = onReschedule) { Text("بازسازی") } }
        SettingRow("پشتیبان JSON", "خروجی و بازیابی اطلاعات محلی", Icons.Default.Backup) {
            Row {
                TextButton(onClick = onImport) { Text("Import") }
                TextButton(onClick = onExport) { Text("Export") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("درباره نسخه ۱", fontWeight = FontWeight.Bold)
                Text("داده‌ها روی دستگاه ذخیره می‌شوند. همگام‌سازی تقویم، ویجت، Wear OS و قابلیت‌های AI برای فاز دوم در معماری پیش‌بینی شده‌اند.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, control: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(15.dp)).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
        }
        control()
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(15.dp)) {
        Text(message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

private fun formatMinute(minute: Int): String = "%02d:%02d".format(minute / 60, minute % 60)
private fun String.toComposeColor(): Color = try { Color(android.graphics.Color.parseColor(this)) } catch (_: Exception) { Color.Gray }
