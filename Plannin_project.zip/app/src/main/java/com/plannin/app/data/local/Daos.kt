package com.plannin.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY createdAt") fun observeAll(): Flow<List<GoalEntity>>
    @Query("SELECT * FROM goals ORDER BY createdAt") suspend fun getAllSnapshot(): List<GoalEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<GoalEntity>)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY priority ASC, sortOrder ASC") fun observeAll(): Flow<List<ProjectEntity>>
    @Query("SELECT * FROM projects ORDER BY priority ASC, sortOrder ASC") suspend fun getAll(): List<ProjectEntity>
    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1") suspend fun getById(id: String): ProjectEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: ProjectEntity)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(items: List<ProjectEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<ProjectEntity>)
    @Query("UPDATE projects SET status = :status, updatedAt = :updatedAt WHERE id = :id") suspend fun updateStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis())
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY projectId, sortOrder") fun observeAll(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks ORDER BY projectId, sortOrder") suspend fun getAllSnapshot(): List<TaskEntity>
    @Query("SELECT * FROM tasks WHERE projectId = :projectId ORDER BY sortOrder") fun observeByProject(projectId: String): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks WHERE projectId = :projectId ORDER BY sortOrder") suspend fun getByProject(projectId: String): List<TaskEntity>
    @Query("SELECT * FROM tasks WHERE status != 'DONE' ORDER BY projectId, sortOrder") suspend fun getPending(): List<TaskEntity>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(items: List<TaskEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: TaskEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<TaskEntity>)
    @Query("UPDATE tasks SET status = :status, completedAt = :completedAt WHERE id = :id") suspend fun updateStatus(id: String, status: String, completedAt: Long? = null)
    @Query("UPDATE tasks SET status = 'IN_PROGRESS' WHERE projectId = :projectId AND status = 'TODO'") suspend fun startPendingTasks(projectId: String)
}

@Dao
interface TimeBlockDao {
    @Query("SELECT * FROM time_blocks WHERE isEnabled = 1 ORDER BY dayOfWeekIso, startMinute") fun observeEnabled(): Flow<List<TimeBlockEntity>>
    @Query("SELECT * FROM time_blocks WHERE isEnabled = 1 ORDER BY dayOfWeekIso, startMinute") suspend fun getEnabled(): List<TimeBlockEntity>
    @Query("SELECT * FROM time_blocks ORDER BY dayOfWeekIso, startMinute") suspend fun getAllSnapshot(): List<TimeBlockEntity>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(items: List<TimeBlockEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(item: TimeBlockEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<TimeBlockEntity>)
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits WHERE isEnabled = 1 ORDER BY title") fun observeEnabled(): Flow<List<HabitEntity>>
    @Query("SELECT * FROM habits WHERE isEnabled = 1 ORDER BY title") suspend fun getEnabled(): List<HabitEntity>
    @Query("SELECT * FROM habits ORDER BY title") suspend fun getAllSnapshot(): List<HabitEntity>
    @Query("SELECT * FROM habit_logs ORDER BY dateEpochDay") suspend fun getAllLogs(): List<HabitLogEntity>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(items: List<HabitEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<HabitEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertLogs(items: List<HabitLogEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLog(item: HabitLogEntity)
    @Query("SELECT * FROM habit_logs WHERE dateEpochDay = :dateEpochDay") fun logsForDay(dateEpochDay: Long): Flow<List<HabitLogEntity>>
}

@Dao
interface JournalDao {
    @Query("SELECT * FROM journal_entries ORDER BY createdAt DESC") fun observeAll(): Flow<List<JournalEntryEntity>>
    @Query("SELECT * FROM journal_entries WHERE body LIKE '%' || :query || '%' ORDER BY createdAt DESC") fun search(query: String): Flow<List<JournalEntryEntity>>
    @Query("SELECT * FROM journal_entries ORDER BY createdAt DESC") suspend fun getAllSnapshot(): List<JournalEntryEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: JournalEntryEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<JournalEntryEntity>)
}

@Dao
interface DecisionLogDao {
    @Query("SELECT * FROM decision_logs ORDER BY createdAt DESC") fun observeAll(): Flow<List<DecisionLogEntity>>
    @Query("SELECT * FROM decision_logs ORDER BY createdAt DESC") suspend fun getAllSnapshot(): List<DecisionLogEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: DecisionLogEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<DecisionLogEntity>)
}


@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY actualStartMillis DESC")
    suspend fun getAllSnapshot(): List<SessionEntity>

    @Query("SELECT * FROM sessions WHERE dateEpochDay = :dateEpochDay ORDER BY actualStartMillis DESC")
    fun observeForDay(dateEpochDay: Long): Flow<List<SessionEntity>>

    @Query("SELECT * FROM sessions WHERE status IN ('RUNNING','PAUSED') ORDER BY actualStartMillis DESC LIMIT 1")
    fun observeActive(): Flow<SessionEntity?>

    @Query("SELECT * FROM sessions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): SessionEntity?

    @Query("SELECT * FROM sessions WHERE status IN ('RUNNING','PAUSED') ORDER BY actualStartMillis DESC LIMIT 1")
    suspend fun getActiveSession(): SessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: SessionEntity)
}
