package com.plannin.app

import android.app.Application
import com.plannin.app.data.local.PlanninDatabase
import com.plannin.app.data.local.seedIfEmpty
import com.plannin.app.scheduler.NotificationChannels
import com.plannin.app.scheduler.AlarmScheduler
import com.plannin.app.scheduler.PlanninWork
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PlanninApplication : Application() {
    val database by lazy { PlanninDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.create(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            database.seedIfEmpty()
            AlarmScheduler.scheduleUpcoming(this@PlanninApplication, database.timeBlockDao().getEnabled(), database.habitDao().getEnabled())
            PlanninWork.scheduleDailySummary(this@PlanninApplication)
        }
    }
}
