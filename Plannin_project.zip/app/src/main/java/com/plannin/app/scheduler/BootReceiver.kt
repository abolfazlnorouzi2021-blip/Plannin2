package com.plannin.app.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.plannin.app.data.local.PlanninDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val async = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = PlanninDatabase.get(context)
                AlarmScheduler.scheduleUpcoming(context, db.timeBlockDao().getEnabled(), db.habitDao().getEnabled())
            } finally { async.finish() }
        }
    }
}
