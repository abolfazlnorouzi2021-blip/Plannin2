package com.plannin.app.domain

import com.plannin.app.data.local.TimeBlockEntity
import java.time.LocalDate
import java.time.LocalTime

object PlannerRules {
    fun activeBlock(blocks: List<TimeBlockEntity>, now: LocalTime, day: Int): TimeBlockEntity? =
        blocks.firstOrNull {
            it.dayOfWeekIso == day && it.blockType == "PROJECT" && !it.isFlexible &&
                now.toSecondOfDay() / 60 in it.startMinute until it.endMinute
        }

    fun nextBlock(blocks: List<TimeBlockEntity>, now: LocalTime, day: Int): TimeBlockEntity? =
        blocks.filter { it.dayOfWeekIso == day && it.blockType == "PROJECT" && !it.isFlexible && it.startMinute > now.hour * 60 + now.minute }
            .minByOrNull { it.startMinute }

    fun isLightDay(date: LocalDate): Boolean = date.dayOfWeek.value == 7

    fun isPersonalFree(block: TimeBlockEntity): Boolean =
        block.blockType == "PERSONAL_FREE" || block.isOptional

    fun isHabitDay(daysCsv: String, isoDay: Int): Boolean =
        daysCsv.split(',').mapNotNull { it.trim().toIntOrNull() }.contains(isoDay)

    fun performanceWeight(priority: Int): Double = when (priority) {
        1 -> 3.0
        2 -> 2.0
        3 -> 1.5
        4 -> 1.0
        else -> 0.75
    }
}
