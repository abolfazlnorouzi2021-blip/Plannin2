package com.plannin.app.scheduler

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.plannin.app.MainActivity
import com.plannin.app.R
import com.plannin.app.data.local.PlanninDatabase
import com.plannin.app.data.local.TaskEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BlockAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = intent.getStringExtra(AlarmScheduler.EXTRA_EVENT_TYPE) ?: return
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) ?: "یادآوری Plannin"
        if (event == AlarmScheduler.EVENT_HABIT) {
            val channel = intent.getStringExtra(AlarmScheduler.EXTRA_CHANNEL_ID) ?: NotificationChannels.WORKOUT
            showHabit(context, title, channel, intent.action.hashCode())
            return
        }

        val projectId = intent.getStringExtra(AlarmScheduler.EXTRA_PROJECT_ID) ?: return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = PlanninDatabase.get(context)
                val project = db.projectDao().getById(projectId)
                val projectName = project?.name ?: title
                if (event == AlarmScheduler.EVENT_START) {
                    db.taskDao().startPendingTasks(projectId)
                    showStart(context, projectName, intent.action.hashCode())
                } else {
                    val pendingTasks = db.taskDao().getByProject(projectId).filter { it.status != "DONE" }
                    showCheckIn(context, projectId, projectName, pendingTasks, intent.action.hashCode())
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showStart(context: Context, projectName: String, id: Int) {
        val openApp = PendingIntent.getActivity(context, id, Intent(context, com.plannin.app.MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, NotificationChannels.BLOCK_START)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(openApp)
            .setContentTitle("الان زمان پروژه $projectName است")
            .setContentText("تمرکز ۱۰۰٪؛ فقط روی همین پروژه کار کن.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        notifySafely(context, id, notification)
    }

    private fun showCheckIn(context: Context, projectId: String, projectName: String, tasks: List<TaskEntity>, id: Int) {
        val partialIntent = Intent(context, CheckInActionReceiver::class.java).apply {
            action = CheckInActionReceiver.ACTION_BLOCK_PARTIAL
            putExtra(CheckInActionReceiver.EXTRA_PROJECT_ID, projectId)
        }
        val partialPi = PendingIntent.getBroadcast(context, id + 2, partialIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val taskText = if (tasks.isEmpty()) "کار ثبت‌نشده‌ای باقی نمانده است." else "باقی‌مانده: ${tasks.take(4).joinToString("، ") { it.title }}"
        val builder = NotificationCompat.Builder(context, NotificationChannels.BLOCK_CHECK_IN)
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("خان، عملکردت در پروژه $projectName چطور بود؟")
            .setContentText(taskText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(taskText))
            .addAction(0, "ثبت بلوک ناقص", partialPi)
            .setAutoCancel(true)
        tasks.take(3).forEachIndexed { index, task ->
            val taskIntent = Intent(context, CheckInActionReceiver::class.java).apply {
                action = CheckInActionReceiver.ACTION_TASK_DONE
                putExtra(CheckInActionReceiver.EXTRA_PROJECT_ID, projectId)
                putExtra(CheckInActionReceiver.EXTRA_TASK_ID, task.id)
            }
            val taskPi = PendingIntent.getBroadcast(context, id + 10 + index, taskIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            builder.addAction(0, "✓ ${task.title.take(18)}", taskPi)
        }
        val openApp = PendingIntent.getActivity(context, id, Intent(context, com.plannin.app.MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = builder.setContentIntent(openApp).build()
        notifySafely(context, id, notification)
    }

    private fun showHabit(context: Context, title: String, channel: String, id: Int) {
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("یادآوری عادت روزانه")
            .setContentText("زمان $title است.")
            .setAutoCancel(true)
            .build()
        notifySafely(context, id, notification)
    }

    private fun notifySafely(context: Context, id: Int, notification: android.app.Notification) {
        try { NotificationManagerCompat.from(context).notify(id, notification) } catch (_: SecurityException) { }
    }
}
