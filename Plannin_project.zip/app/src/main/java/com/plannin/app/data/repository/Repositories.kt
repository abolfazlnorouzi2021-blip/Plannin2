package com.plannin.app.data.repository

import com.plannin.app.data.local.*
import kotlinx.coroutines.flow.Flow

interface PlannerRepository {
    fun projects(): Flow<List<ProjectEntity>>
    fun tasks(): Flow<List<TaskEntity>>
    fun blocks(): Flow<List<TimeBlockEntity>>
    suspend fun updateTaskStatus(taskId: String, status: String)
    suspend fun startProject(projectId: String)
}

interface JournalRepository {
    fun entries(): Flow<List<JournalEntryEntity>>
    fun search(query: String): Flow<List<JournalEntryEntity>>
    suspend fun add(entry: JournalEntryEntity)
}

class RoomPlannerRepository(private val db: PlanninDatabase) : PlannerRepository {
    override fun projects() = db.projectDao().observeAll()
    override fun tasks() = db.taskDao().observeAll()
    override fun blocks() = db.timeBlockDao().observeEnabled()
    override suspend fun updateTaskStatus(taskId: String, status: String) {
        db.taskDao().updateStatus(taskId, status, if (status == "DONE") System.currentTimeMillis() else null)
    }
    override suspend fun startProject(projectId: String) {
        db.taskDao().startPendingTasks(projectId)
    }
}

class RoomJournalRepository(private val db: PlanninDatabase) : JournalRepository {
    override fun entries() = db.journalDao().observeAll()
    override fun search(query: String) = db.journalDao().search(query)
    override suspend fun add(entry: JournalEntryEntity) = db.journalDao().insert(entry)
}
