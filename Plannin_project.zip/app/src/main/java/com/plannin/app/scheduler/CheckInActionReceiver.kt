package com.plannin.app.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.plannin.app.data.local.DecisionLogEntity
import com.plannin.app.data.local.PlanninDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

class CheckInActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val projectId = intent.getStringExtra(EXTRA_PROJECT_ID) ?: return
        val action = intent.action ?: return
        val taskId = intent.getStringExtra(EXTRA_TASK_ID)
        val async = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = PlanninDatabase.get(context)
                when (action) {
                    ACTION_TASK_DONE -> {
                        if (taskId != null) db.taskDao().updateStatus(taskId, "DONE", System.currentTimeMillis())
                    }
                    ACTION_BLOCK_PARTIAL -> Unit
                }
                db.decisionLogDao().insert(
                    DecisionLogEntity(
                        id = UUID.randomUUID().toString(), projectId = projectId, taskId = taskId,
                        reason = "NOTIFICATION_CHECK_IN",
                        decision = when (action) {
                            ACTION_TASK_DONE -> "TASK_MARKED_DONE_FROM_NOTIFICATION"
                            else -> "BLOCK_MARKED_PARTIAL"
                        },
                        note = when (action) {
                            ACTION_TASK_DONE -> "کار از اعلان پایان بلوک انجام‌شده ثبت شد."
                            else -> "کاربر بلوک را ناقص ثبت کرد."
                        }
                    )
                )
            } finally { async.finish() }
        }
    }

    companion object {
        const val EXTRA_PROJECT_ID = "project_id"
        const val EXTRA_TASK_ID = "task_id"
        const val ACTION_TASK_DONE = "com.plannin.ACTION_TASK_DONE"
        const val ACTION_BLOCK_PARTIAL = "com.plannin.ACTION_BLOCK_PARTIAL"
    }
}
