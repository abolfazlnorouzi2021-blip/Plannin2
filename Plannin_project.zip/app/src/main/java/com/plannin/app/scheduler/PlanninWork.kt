package com.plannin.app.scheduler

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.plannin.app.data.local.JournalEntryEntity
import com.plannin.app.data.local.PlanninDatabase
import java.time.LocalDate
import java.util.UUID
import java.util.concurrent.TimeUnit

class DailySummaryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val db = PlanninDatabase.get(applicationContext)
        val allTasks = db.taskDao().getAllSnapshot()
        val done = allTasks.count { it.status == "DONE" }
        val total = allTasks.size
        val percent = if (total == 0) 0 else done * 100 / total
        AlarmScheduler.scheduleUpcoming(applicationContext, db.timeBlockDao().getEnabled(), db.habitDao().getEnabled())
        db.journalDao().insert(
            JournalEntryEntity(
                id = "daily_auto_${LocalDate.now().toEpochDay()}",
                body = "خلاصه خودکار روز: $done از $total کار ثبت‌شده تکمیل شده است ($percent٪).",
                entryType = "DAILY_AUTO",
                metadataJson = "{\"done\":$done,\"total\":$total,\"completionPercent\":$percent}"
            )
        )
        Result.success()
    } catch (_: Exception) { Result.retry() }
}

object PlanninWork {
    fun scheduleDailySummary(context: Context) {
        val request = PeriodicWorkRequestBuilder<DailySummaryWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "plannin_daily_summary", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }
}
