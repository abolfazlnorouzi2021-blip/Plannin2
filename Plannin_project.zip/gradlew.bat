@echo off
setlocal
set GRADLE_VERSION=9.6.0
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set DIST_DIR=%GRADLE_USER_HOME%\plannin\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%DIST_DIR%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_USER_HOME%\plannin" mkdir "%GRADLE_USER_HOME%\plannin"
  echo Downloading Gradle %GRADLE_VERSION% ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_USER_HOME%\plannin\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%GRADLE_USER_HOME%\plannin\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_USER_HOME%\plannin'; Remove-Item '%GRADLE_USER_HOME%\plannin\gradle-%GRADLE_VERSION%-bin.zip'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
