# Plannin v4 — Phase 1

A Persian-first, offline-first Android planning assistant built with Kotlin, Jetpack Compose and Room.

## Phase 1 included

- Luxury dark interface using soft black, charcoal surfaces and restrained matte-gold accents.
- Today screen with a suggested MIT (most important task), current schedule context and daily timeline.
- Manual session control: a block only starts when the user presses **شروع**.
- Dedicated Focus Mode while a session is running: minimal timer, pause/resume and manual end; bottom navigation is hidden.
- Session records store planned block time separately from actual start/end timestamps.
- Actual focus duration subtracts recorded pauses.
- Completed sessions show actual clock time and actual focus duration in the daily timeline.
- Local Room database, seeded project/task/block data, projects and project details, journal, basic reports, habits, and JSON backup/restore.
- Database migration from schema version 1 to 2 adds session tracking without deleting existing local data.

## Build

- JDK 17
- Android SDK Platform 36 / Build Tools 36
- Android Gradle Plugin 9.5.0, Kotlin Compose plugin 2.4.21, Gradle 9.6.0
- Minimum Android: API 26
- Application ID: `com.plannin.app`

The GitHub Actions workflow is `.github/workflows/build-apk.yml`. It extracts `Plannin_project.zip` from the repository root, installs the Android SDK, builds `:app:assembleDebug`, and uploads the APK artifact.

## Phase 1 boundaries

This is the foundation release, not the complete v4 specification. AI/API chat, full natural-language assistant, smart rescheduling, advanced analytics, flashcards, notes library, energy/sleep correlation, full missed-block reason flow, system-level DND integration and advanced notification rituals remain for later phases. Focus Mode currently suppresses Plannin's in-app navigation and the seeded schedule does not issue routine block-start/check-in alerts; Android-wide Do Not Disturb control is not yet implemented.

The build has not been executed in this environment because Android SDK and Gradle are not installed here. Use GitHub Actions to compile it and surface any remaining compiler or dependency issues.
